from cssefwebfront import signals
default_app_config = 'cssefwebfront.config.cssefwebfront_config'